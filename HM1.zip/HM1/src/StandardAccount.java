public class StandardAccount implements IAccount {



    //State
    int accountNumber;
    double creditLimit;

    //Constructor
    public StandardAccount(int accountNumber, double creditLimit) {
        this.accountNumber = accountNumber;
        this.creditLimit = creditLimit;
    }

//Behaviour

    public int getAccountNumber() {
        return accountNumber;
    }

    @Override
    public void Deposit(double amount) {

    }

    @Override
    public double Withdraw(double amount) {
        return 0;
    }

    @Override
    public double GetCurrentBalance() {
        return 0;
    }

    @Override
    public int GetAccountNumber() {
        return accountNumber;
    }
}
