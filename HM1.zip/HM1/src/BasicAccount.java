public class BasicAccount implements IAccount {



    //State
    int accountNumber;
    double withdrawalLimit;

    //Constructor
    public BasicAccount(int accountNumber, double creditLimit) {
        this.accountNumber = accountNumber;
        this.withdrawalLimit = withdrawalLimit;
    }

//Behaviour

    @Override
    public void Deposit(double amount) {

    }

    @Override
    public double Withdraw(double amount) {
        if (withdrawalLimit > amount) {
            return amount;
        } else {
            return withdrawalLimit;
        }
    }



    @Override
    public double GetCurrentBalance() {
        return 0;
    }

    @Override
    public int GetAccountNumber() {
        return accountNumber;
    }
}
