
import java.util.ArrayList;
import java.util.list;

public class Main {
    public static void main(String[] args)
        List<IAccount> Accounts;
    Accounts.add(new Accounts)


}

}