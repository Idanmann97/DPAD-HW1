public class PremiumAccount implements IAccount {



    //State
    int accountNumber;

    //Constructor
    public PremiumAccount(int accountNumber) {
        this.accountNumber = accountNumber;
    }

//Behaviour

    public int getAccountNumber() {
        return accountNumber;
    }

    @Override
    public void Deposit(double amount) {

    }

    @Override
    public double Withdraw(double amount) {
        return 0;
    }

    @Override
    public double GetCurrentBalance() {
        return 0;
    }

    @Override
    public int GetAccountNumber() {
        return accountNumber;
    }
}
